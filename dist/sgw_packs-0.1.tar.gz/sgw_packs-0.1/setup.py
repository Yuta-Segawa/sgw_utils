# from distutils.core import setup
from setuptools import setup, find_packages
setup(name='sgw_packs',
      version='0.1',
      description='My package for experiments. ',
      author='Yuta Segawa',
      author_email='ghunterysys@gmail.com',
      packages=find_packages()
     )