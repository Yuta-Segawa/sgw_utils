import os, glob, cv2, random
import numpy as np
from keras.preprocessing import image
from multiprocessing import Process, Queue, Pool
from keras.preprocessing.image import ImageDataGenerator
import tensorflow as tf
import keras.backend as K
import itertools as it
from keras.applications.imagenet_utils import preprocess_input
from keras.utils.np_utils import to_categorical, probas_to_classes

# this script includes 2 types of image preparation modules:
# 1. load all images at one time and feed images from RAM
# 2. load batch images from directory and feed the images

##############
### common ###
##############

def convert_to_onehot(labels):
    nb_classes = labels.max()
    return to_categorical(lables, nb_classes)

####################################
### for local pattern prediction ###
####################################

def crop_imgs(img, patch_size=32, return_locs=False, return_loc_masks=False):
    tl_x_locs = np.arange(0, img.shape[1], patch_size)
    tl_y_locs = np.arange(0, img.shape[0], patch_size)
    tl_locs = np.array(list(it.product(tl_y_locs, tl_x_locs)))
    br_locs = tl_locs + np.array([patch_size, patch_size])
    mirrored_img = np.hstack([np.vstack([img, img[::-1]]), np.vstack([img[::, ::-1], img[::-1, ::-1]])])

    if return_locs:
        return [mirrored_img[tl[0]:br[0], tl[1]:br[1]] for tl, br in zip(tl_locs, br_locs)], zip(tl_locs, br_locs)
    else:
        return [mirrored_img[tl[0]:br[0], tl[1]:br[1]] for tl, br in zip(tl_locs, br_locs)]

def get_crop_locs(shape, patch_size=32):
    tl_x_locs = np.arange(0, shape[1], patch_size)
    tl_y_locs = np.arange(0, shape[0], patch_size)
    tl_locs = np.array(list(it.product(tl_y_locs, tl_x_locs)))
    br_locs = tl_locs + np.array([patch_size, patch_size])
    return zip(tl_locs, br_locs)

def get_crop_masks(shape, patch_size=32):
    locs = get_crop_locs(shape, patch_size)
    loc_masks = []
    for l in locs: 
        mask = np.zeros(shape[:2]).astype(bool)
        mask[l[0][0]:l[1][0], l[0][1]:l[1][1]] = 1
        loc_masks.append(mask)
    return loc_masks


##############
### type 1 ###
##############
def resize_and_transpose(img_fn, shape):
    return image.img_to_array(image.load_img(img_fn, target_size=shape)).astype(float)
def mp_func(args):
    return resize_and_transpose(args[0], args[1])

# for training adn evaluation
def load_images_from_dirs(basedir, classnames, 
    image_shape=(256, 256), extension="jpg", max_smps=-1, mp_nums=1):
    # only_labels: A flag to avoid to resizing images by reading only labels
    # max_smps: Number of images per a class which should be loaded. -1 means load maximum number as possible

    # get filenames from directories of the classes
    dirnames = [ os.path.join(basedir, cls) for cls in classnames 
                if os.path.exists(os.path.join(basedir, cls)) ]
    if not len(dirnames) == len(classnames):
        print("[I]Too few classes are found (expected %d classes, but %d). " % (len(classnames), len(dirnames)))
        return None
    img_filenames = [ sorted(glob.glob(os.path.join(dirname, "*.%s" % extension))) 
                    for dirname in dirnames ]
    # display info
    for idx, (found_dir, fns) in enumerate(zip(dirnames, img_filenames)):
        print("[I]Found %d images in %s. labeled them as %d. " % (len(fns), found_dir, idx))
        if max_smps != -1: 
            max_smps = min(len(fns), max_smps) 

    # load all images
    print("[I]Resize with shape %s" % str(image_shape))
    mp_status = 'enabled with %d threads' % mp_nums if not mp_nums == 1 else 'disable'
    print("[I]( Multi-Processing: %s)" % mp_status)

    loaded_imgs = []
    for i, cls_img_fns in enumerate(img_filenames):

        if max_smps != -1:
            random.shuffle(cls_img_fns)
            cls_img_fns = cls_img_fns[0:max_smps]
            
        print("[I]Resizing %d images belonging to the class %d. " % (len(cls_img_fns), i))

        if mp_nums > 1:
            p = Pool(mp_nums)
            loaded_imgs.append(np.array(p.map(mp_func, zip(cls_img_fns, [image_shape]*len(cls_img_fns))), float))
            p.close()
        else:
            loaded_imgs.append(np.array([mp_func(args) for args in zip(cls_img_fns, [image_shape]*len(cls_img_fns))], float))

    # make one-hot vectors as training labels
    labels = [ np.array([idx] * len(imgs)).astype(int) for idx, imgs in enumerate(img_filenames) ]
    if max_smps != -1:
        labels = [ l[0:max_smps] for l in labels ]
    one_hot_vectors = [  np.zeros((len(class_label), len(labels))) for class_label in labels ]
    for class_label, v in zip(labels, one_hot_vectors):
        v[np.arange(len(v)), class_label] = 1

    print("[I]Loaded all images and labels. ")

    return loaded_imgs, one_hot_vectors

# for prediction
def load_images_in_dir(dirname, 
    image_shape=(256, 256), extension="jpg", max_smps=-1, mp_nums=1):
    # only_labels: A flag to avoid to resizing images by reading only labels
    # max_smps: Number of images per a class which should be loaded. -1 means load maximum number as possible

    # get filenames from directories of the classes
    img_filenames = sorted(glob.glob(os.path.join(dirname, "*.%s" % extension)))

    # display info
    print("[I]Found %d images in %s. " % (len(img_filenames), dirname))
    if max_smps != -1: 
        max_smps = min(len(img_filenames), max_smps) 

    loaded_imgs = []
    if max_smps != -1:
        random.shuffle(img_filenames)
        img_filenames = img_filenames[0:max_smps]

    print("[I]Use %d images. " % len(img_filenames))

    # load all images
    if image_shape is None:
        print("[I]Not any resizing. ")
    else: 
        print("[I]Resizing with shape %s..." % str(image_shape))
    mp_status = 'enabled with %d threads' % mp_nums if not mp_nums == 1 else 'disable'
    print("[I]( Multi-Processing: %s)" % mp_status)


    if mp_nums > 1:
        p = Pool(mp_nums)
        loaded_imgs = np.array(p.map(mp_func, zip(img_filenames, [image_shape]*len(img_filenames)))).astype(float)
        p.close()
    else:
        loaded_imgs = np.array([mp_func(args) for args in zip(img_filenames, [image_shape]*len(img_filenames))]).astype(float)

    return loaded_imgs

def preprocess_on_images(images, type='inception', vervosity=1):

    # determinant preprocessing
    if vervosity:
        print("[I]Applying preprocessing. ")
        print("[I](Preprocessing type: %s)" % type)
    if type == 'inception':
        images /= 255.0
        images -= 0.5
        images *= 2.0
    elif type  == 'vgg':
        images = preprocess_input(images)
    elif type == 'disable':
        pass
    else: 
        print("[E]Invalid preprocessing type", type)
        return None
    return images

def split_into_batches(data, batch_size=100):
    if len(data) <= batch_size:
        return data
    else:
        return np.array_split(data, range(batch_size, len(data), batch_size))
